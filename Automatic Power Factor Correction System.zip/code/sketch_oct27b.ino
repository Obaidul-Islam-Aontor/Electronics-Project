#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Arduino.h>

#define XOR_PIN 14   // GPIO14 on ESP32
#define ZMPT_PIN 34  // ZMPT101B voltage input
LiquidCrystal_I2C lcd(0x27, 20, 4);  // 20x4 LCD

// Relay pins (adjust as needed)
const int relays[] = {16, 17, 18, 19};
const int NUM_RELAYS = 4;
bool relayStates[NUM_RELAYS] = {HIGH, HIGH, HIGH, HIGH}; // all OFF initially

// ===== PF Measurement variables =====
volatile unsigned long lastEdgeTime = 0;
volatile unsigned long measuredPulse = 0;
volatile bool pulseReady = false;
volatile bool lastLevel = LOW;

const float MAINS_FREQ = 50.0;
const unsigned long PERIOD_US = (unsigned long)(1000000.0 / MAINS_FREQ);
const unsigned long MAX_ACCEPT_US = PERIOD_US * 12UL / 10UL; // 1.2x period
const float CALIBRATION_FACTOR = 0.95; // Adjust experimentally

float powerFactor = 1.0;

// ===== Voltage Measurement variables =====
float offset = 2048;          // ESP32 ADC midpoint
float sensitivity = 0.0075;   // Adjust this to match actual mains voltage

// ===== ISR for XOR Input =====
void IRAM_ATTR xorIsr() {
  bool level = digitalRead(XOR_PIN);
  unsigned long t = micros();

  if (level == HIGH && lastLevel == LOW) {
    lastEdgeTime = t;
  } 
  else if (level == LOW && lastLevel == HIGH) {
    if (lastEdgeTime != 0) {
      unsigned long width = t - lastEdgeTime;
      if (width > 50 && width <= MAX_ACCEPT_US) {
        measuredPulse = width;
        pulseReady = true;
      }
      lastEdgeTime = 0;
    }
  }
  lastLevel = level;
}

// ===== Setup =====
void setup() {
  Serial.begin(115200);

  // Initialize I2C for LCD
  Wire.begin(26, 27);  // SDA=26, SCL=27
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Power Factor:");
  delay(1500);
  lcd.clear();

  pinMode(XOR_PIN, INPUT_PULLDOWN);
  attachInterrupt(digitalPinToInterrupt(XOR_PIN), xorIsr, CHANGE);

  for (int i = 0; i < NUM_RELAYS; i++) {
    pinMode(relays[i], OUTPUT);
    digitalWrite(relays[i], HIGH); // all OFF
  }

  Serial.println("System Initialized.");
}

// ===== Relay Functions =====
void setRelay(int index, bool newState) {
  if (index >= 0 && index < NUM_RELAYS && relayStates[index] != newState) {
    digitalWrite(relays[index], newState);
    relayStates[index] = newState;
  }
}

void setAllRelays(bool state) {
  for (int i = 0; i < NUM_RELAYS; i++) setRelay(i, state);
}

// ===== PF Measurement =====
float measurePF() {
  noInterrupts();
  bool ready = pulseReady;
  unsigned long pulse_us = measuredPulse;
  if (ready) {
    pulseReady = false;
    measuredPulse = 0;
  }
  interrupts();

  if (ready) {
    float duty = (float)pulse_us / (float)PERIOD_US;
    duty = constrain(duty, 0.0, 1.0);
    float phaseRad = duty * PI * CALIBRATION_FACTOR;
    return fabs(cos(phaseRad));
  }

  return powerFactor; // return last valid PF if no new data
}

float getAveragePF() {
  float sumPF = 0;
  int count = 0;
  unsigned long startTime = millis();

  while (millis() - startTime < 10000) { // 10s window
    float pf = measurePF();
    if (pf > 0.4 && pf <= 1.0) { // valid range
      sumPF += pf;
      count++;
      Serial.print("PF sample: ");
      Serial.println(pf, 3);
    }
    delay(random(400, 600)); // jitter
  }

  if (count > 0) return sumPF / count;
  Serial.println("No valid signal detected!");
  return 1.0;
}

// ===== Voltage Measurement =====
int measureVoltage() {
  int sampleCount = 1000;
  float sumSq = 0;

  for (int i = 0; i < sampleCount; i++) {
    int raw = analogRead(ZMPT_PIN);
    float centered = raw - offset;
    sumSq += centered * centered;
    delayMicroseconds(20);
  }

  float rms_adc = sqrt(sumSq / sampleCount);
  float adc_voltage = (rms_adc * 3.3) / 4095.0;
  float ac_voltage = adc_voltage / sensitivity;

  return (int)(ac_voltage + 0.5); // convert to integer with rounding
}

// ===== LCD Update =====
void displayPF(float pf, const char* status) {
  int voltage = measureVoltage(); // read voltage for first line

  // First line: Voltage + PF (3 decimals)
  lcd.setCursor(0, 0);
  lcd.print("V=");
  lcd.print(voltage);
  lcd.print(" PF=");
  lcd.print(pf, 3);  // now shows PF=x.xxx
  lcd.print("     ");

  // Second line: PF status
  lcd.setCursor(0, 1);
  lcd.print(status);
  lcd.print("     ");
}

// ===== Main Loop =====
void loop() {
  setAllRelays(HIGH); // start fresh

  Serial.println("Collecting PF data...");
  displayPF(powerFactor, "Measuring");

  powerFactor = getAveragePF();
  displayPF(powerFactor, "Evaluating");

  Serial.print("Average PF: ");
  Serial.println(powerFactor, 3);

  if (powerFactor >= 0.9) {
    displayPF(powerFactor, "Good");
    Serial.println("PF is good. No correction needed.");
  } 
  else {
    Serial.println("PF Low, correcting...");
    displayPF(powerFactor, "Correcting");

    // Stepwise correction until PF >= 0.95
    for (int i = 0; i < NUM_RELAYS && powerFactor < 0.95; i++) {
      setRelay(i, LOW); // turn on next capacitor
      Serial.printf("Relay %d ON\n", i + 1);
      delay(1000);
      powerFactor = getAveragePF();
      displayPF(powerFactor, "Adjusting");
    }

    // Final display
    if (powerFactor >= 0.9) {
      displayPF(powerFactor, "Good");
      Serial.printf("Corrected PF: %.3f\n", powerFactor);
    } else {
      displayPF(powerFactor, "Low");
      Serial.println("Even max caps can't reach PF >= 0.9");
    }
  }

  delay(5000); // 5s before next evaluation
}
